package com.example.universityhub.activity

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.example.universityhub.R
import com.example.universityhub.adapter.DashboardRecyclerAdapter
import com.example.universityhub.model.University
import com.example.universityhub.util.ConnectionManager
import java.lang.Exception

class DescriptionActivity : AppCompatActivity() {

    lateinit var toolbar: Toolbar
    lateinit var universityNameText:TextView
    lateinit var universityCountry:TextView
    lateinit var universityWebPage:TextView
    lateinit var universityCode:TextView
    lateinit var universityDomain:TextView

    var found:Boolean = false
    lateinit var progressBar:ProgressBar
    lateinit var progressLayout: RelativeLayout
    lateinit var resObj:University

    val universityOnlineInfoList = arrayListOf<University>()

    var universityName:String? = "DAV"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)

        toolbar = findViewById(R.id.descToolbar)
        universityNameText = findViewById(R.id.univName)
        universityCountry = findViewById(R.id.univCountry)
        universityWebPage = findViewById(R.id.univWebLink)
        universityCode = findViewById(R.id.univCode)
        universityDomain = findViewById(R.id.univDomain)
        progressBar = findViewById(R.id.progressBar)
        progressBar.visibility = View.VISIBLE
        progressLayout = findViewById(R.id.progressLayout)
        progressLayout.visibility = View.VISIBLE

        setSupportActionBar(toolbar)
        supportActionBar?.title = "Details"

        if(intent != null){
            universityName = intent.getStringExtra("university_name")
            println("GOT NAME APPANKISHAM")
        }else{
            finish()
            Toast.makeText(this@DescriptionActivity, "Some unexpected error occurred!", Toast.LENGTH_SHORT).show()
        }

        if(universityName == "DAV"){
            finish()
            Toast.makeText(this@DescriptionActivity, "Some unexpected error occurred!", Toast.LENGTH_SHORT).show()
        }

        val queue = Volley.newRequestQueue(this)

        val url = "http://universities.hipolabs.com/search?country=India"

        println("BreakPoint APPANKISHAM")

        val jsonObjectRequest =  object : JsonArrayRequest(Request.Method.GET, url, null, Response.Listener{

            val obj = it.getJSONObject(0)

            try {
                for(i in 0 until it.length()){
                    val jsonObj = it.getJSONObject(i)
                    val univesityObj = University(
                        jsonObj.getString("name"),
                        jsonObj.getString("country"),
                        jsonObj.getJSONArray("web_pages")[0].toString(),
                        jsonObj.getString("alpha_two_code"),
                        jsonObj.getJSONArray("domains")[0].toString()
                    )
                    if(univesityObj.name == universityName)
                    {
                        universityNameText.text = univesityObj.name
                        universityCountry.text = univesityObj.country//"Hello"//resObj.country
                        universityWebPage.text = univesityObj.webPages//"Hello"//resObj.webPages
                        universityCode.text = univesityObj.alphaTwoCode//"Hello"// resObj.alphaTwoCode
                        universityDomain.text = univesityObj.domains//"Hello"//resObj.domains
                        progressBar.visibility = View.INVISIBLE
                        progressLayout.visibility = View.INVISIBLE
                        break
                    }
                    else{
                        //Toast.makeText(this@DescriptionActivity, "Some Error Occured1", Toast.LENGTH_SHORT).show()
                    }
                }
            }catch (e:Exception){
                //Toast.makeText(this@DescriptionActivity, "Some Error Occured2", Toast.LENGTH_SHORT).show()
            }

        }, Response.ErrorListener {
            println("Appankisham Error is $it")
            //Toast.makeText(this@DescriptionActivity, "Some Error Occured3", Toast.LENGTH_SHORT).show()
        }){

        }

        queue.add(jsonObjectRequest)

        if(!ConnectionManager().checkConnectivity(this)) {
            val universityInfoList = arrayListOf<University>(
                University(
                    "DAV Institute of Engineering & Technology",
                    "India",
                    "http://www.davietjal.org/",
                    "IN",
                    "davietjal.org"
                ),
                University(
                    "Lovely Professional University",
                    "India",
                    "http://www.lpu.in/",
                    "IN",
                    "lpu.in"
                ),
                University(
                    "Somaiya Vidyavihar",
                    "India",
                    "https://somaiya.edu/",
                    "IN",
                    "somaiya.edu"
                ),
                University(
                    "NorthCap University",
                    "India",
                    "http://www.ncuindia.edu/",
                    "IN",
                    "ncuindia.edu"
                ),
                University(
                    "Dharamsinh Desai University",
                    "India",
                    "http://www.ddu.ac.in/",
                    "IN",
                    "ddu.ac.in"
                ),
                University(
                    "University of Health Sciences Andhra Pradesh",
                    "India",
                    "http://ntruhs.ap.nic.in/",
                    "IN",
                    "ntruhs.ap.nic.in"
                ),
                University(
                    "Allahabad Agricultural Institute, Deemed University",
                    "India",
                    "http://www.aaidu.org/",
                    "IN",
                    "aaidu.org"
                ),
                University(
                    "Assam Agricultural University",
                    "India",
                    "http://www.aau.ac.in/",
                    "IN",
                    "aau.ac.in"
                ),University(
                    "Ahmedabad University",
                    "India",
                    "http://www.ahduni.edu.in/",
                    "IN",
                    "ahduni.edu.in"
                ),
                University(
                    "All India Institute of Medical Sciences",
                    "India",
                    "http://www.aiims.ac.in/",
                    "IN",
                    "aiims.ac.in"
                ),
                University(
                    "AISECT University",
                    "India",
                    "http://www.aisectuniversity.ac.in/",
                    "IN",
                    "aisectuniversity.ac.in"
                ),
                University(
                    "Alagappa University",
                    "India",
                    "http://www.alagappauniversity.ac.in/",
                    "IN",
                    "alagappauniversity.ac.in"
                ),
                University(
                    "Allahabad University",
                    "India",
                    "http://www.alldunivpio.org/",
                    "IN",
                    "alldunivpio.org"
                ),
                University(
                    "Open International University for Alternative Medicines",
                    "India",
                    "http://www.altmeduniversity.com/",
                    "IN",
                    "alldunivpio.org"
                ),
                University(
                    "Indian Board of Alternative Medicine",
                    "India",
                    "http://www.altmedworld.net/",
                    "IN",
                    "altmedworld.net"
                ),
                University(
                    "Amity University",
                    "India",
                    "http://www.amity.edu/",
                    "IN",
                    "amity.edu"
                ),
                University(
                    "Amrita Vishwa Vidyapeetham (Deemed University)",
                    "India",
                    "http://www.amrita.edu/",
                    "IN",
                    "amrita.edu"
                ),
                University(
                    "Amravati University",
                    "India",
                    "http://www.amtuni.com/",
                    "IN",
                    "amtuni.com"
                ),
                University(
                    "Aligarh Muslim University",
                    "India",
                    "http://www.amu.ac.in/",
                    "IN",
                    "amu.ac.in"
                ),
                University(
                    "Andhra University",
                    "India",
                    "http://www.andhrauniversity.info/",
                    "IN",
                    "andhrauniversity.info"
                )
            )
            for(univesityObj in universityInfoList){
                if(univesityObj.name == universityName){
                    universityNameText.text = univesityObj.name
                    universityCountry.text = univesityObj.country//"Hello"//resObj.country
                    universityWebPage.text = univesityObj.webPages//"Hello"//resObj.webPages
                    universityCode.text = univesityObj.alphaTwoCode//"Hello"// resObj.alphaTwoCode
                    universityDomain.text = univesityObj.domains//"Hello"//resObj.domains
                    progressBar.visibility = View.INVISIBLE
                    progressLayout.visibility = View.INVISIBLE
                }
            }
        }
    }

}