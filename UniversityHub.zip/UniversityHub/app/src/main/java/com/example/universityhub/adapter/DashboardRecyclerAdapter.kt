package com.example.universityhub.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.*
import com.example.universityhub.R
import com.example.universityhub.activity.DescriptionActivity
import com.example.universityhub.model.University

class DashboardRecyclerAdapter(val context:Context, val itemList: ArrayList<University>): RecyclerView.Adapter<DashboardRecyclerAdapter.DashboardViewHolder>(){

    class DashboardViewHolder(view: View): ViewHolder(view){
        val nameView: TextView = view.findViewById(R.id.txtUniversityNameItem)
        val rlContent:RelativeLayout = view.findViewById(R.id.rlContent)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_dashboard_single_row, parent, false)

        return DashboardViewHolder(view)
    }

    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
        val university = itemList[position]
        holder.nameView.text = university.name

        holder.rlContent.setOnClickListener{
            //Toast.makeText(context, "Clicked on ${holder.nameView.text}", Toast.LENGTH_SHORT).show()
            val intent = Intent(context, DescriptionActivity::class.java)
            intent.putExtra("university_name", university.name)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return itemList.size
    }
}