package com.example.universityhub.fragment

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.universityhub.R
import com.example.universityhub.adapter.DashboardRecyclerAdapter
import com.example.universityhub.model.University
import com.example.universityhub.util.ConnectionManager

//private const val ARG_PARAM1 = "param1"
//private const val ARG_PARAM2 = "param2"


class DashboardFragment : Fragment() {

    /*
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }
    */

    lateinit var recyclerDashboard: RecyclerView

    lateinit var layoutManager: RecyclerView.LayoutManager

    val universityList = arrayListOf(
        "DAV",
        "LPU",
        "Somaiya VV",
        "NorthCap",
        "DDU",
        "UHSAP",
        "AAIDU",
        "AAU",
        "ALU",
        "IIMS",
        "DAV",
        "LPU",
        "Somaiya VV",
        "NorthCap",
        "DDU",
        "UHSAP",
        "AAIDU",
        "AAU",
        "ALU",
        "IIMS"
    )
    val universityOnlineInfoList = arrayListOf<University>()
    val universityInfoList = arrayListOf<University>(
        University(
            "DAV Institute of Engineering & Technology",
            "India",
            "http://www.davietjal.org/",
            "IN",
            "davietjal.org"
        ),
        University(
            "Lovely Professional University",
            "India",
            "http://www.lpu.in/",
            "IN",
            "lpu.in"
        ),
        University(
            "Somaiya Vidyavihar",
            "India",
            "https://somaiya.edu/",
            "IN",
            "somaiya.edu"
        ),
        University(
            "NorthCap University",
            "India",
            "http://www.ncuindia.edu/",
            "IN",
            "ncuindia.edu"
        ),
        University(
            "Dharamsinh Desai University",
            "India",
            "http://www.ddu.ac.in/",
            "IN",
            "ddu.ac.in"
        ),
        University(
            "University of Health Sciences Andhra Pradesh",
            "India",
            "http://ntruhs.ap.nic.in/",
            "IN",
            "ntruhs.ap.nic.in"
        ),
        University(
            "Allahabad Agricultural Institute, Deemed University",
            "India",
            "http://www.aaidu.org/",
            "IN",
            "aaidu.org"
        ),
        University(
            "Assam Agricultural University",
            "India",
            "http://www.aau.ac.in/",
            "IN",
            "aau.ac.in"
        ),University(
            "Ahmedabad University",
            "India",
            "http://www.ahduni.edu.in/",
            "IN",
            "ahduni.edu.in"
        ),
        University(
            "All India Institute of Medical Sciences",
            "India",
            "http://www.aiims.ac.in/",
            "IN",
            "aiims.ac.in"
        ),
        University(
            "AISECT University",
            "India",
            "http://www.aisectuniversity.ac.in/",
            "IN",
            "aisectuniversity.ac.in"
        ),
        University(
            "Alagappa University",
            "India",
            "http://www.alagappauniversity.ac.in/",
            "IN",
            "alagappauniversity.ac.in"
        ),
        University(
            "Allahabad University",
            "India",
            "http://www.alldunivpio.org/",
            "IN",
            "alldunivpio.org"
        ),
        University(
            "Open International University for Alternative Medicines",
            "India",
            "http://www.altmeduniversity.com/",
            "IN",
            "alldunivpio.org"
        ),
        University(
            "Indian Board of Alternative Medicine",
            "India",
            "http://www.altmedworld.net/",
            "IN",
            "altmedworld.net"
        ),
        University(
            "Amity University",
            "India",
            "http://www.amity.edu/",
            "IN",
            "amity.edu"
        ),
        University(
            "Amrita Vishwa Vidyapeetham (Deemed University)",
            "India",
            "http://www.amrita.edu/",
            "IN",
            "amrita.edu"
        ),
        University(
            "Amravati University",
            "India",
            "http://www.amtuni.com/",
            "IN",
            "amtuni.com"
        ),
        University(
            "Aligarh Muslim University",
            "India",
            "http://www.amu.ac.in/",
            "IN",
            "amu.ac.in"
        ),
        University(
            "Andhra University",
            "India",
            "http://www.andhrauniversity.info/",
            "IN",
            "andhrauniversity.info"
        )
    )

    lateinit var recyclerAdapter: DashboardRecyclerAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {



        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)

        recyclerDashboard = view.findViewById(R.id.recyclerDashboard)

        layoutManager = LinearLayoutManager(activity)

        recyclerAdapter = DashboardRecyclerAdapter(activity as Context, universityInfoList)

        recyclerDashboard.adapter = recyclerAdapter

        recyclerDashboard.layoutManager = layoutManager

        recyclerDashboard.addItemDecoration(
            DividerItemDecoration(
                recyclerDashboard.context,
                (layoutManager as LinearLayoutManager).orientation
            )
        )


        val queue = Volley.newRequestQueue(activity as Context)

        val url = "http://universities.hipolabs.com/search?country=India"

        val jsonObjectRequest =  object : JsonArrayRequest(Request.Method.GET, url, null, Response.Listener{

            val obj = it.getJSONObject(0)

            for(i in 0 until it.length()){
                val jsonObj = it.getJSONObject(i)
                val univesityObj = University(
                    jsonObj.getString("name"),
                    jsonObj.getString("country"),
                    jsonObj.getJSONArray("web_pages")[0].toString(),
                    jsonObj.getString("alpha_two_code"),
                    jsonObj.getJSONArray("domains")[0].toString()
                )
                universityOnlineInfoList.add(univesityObj)
            }

            if(ConnectionManager().checkConnectivity(activity as Context)) {
                recyclerAdapter = DashboardRecyclerAdapter(activity as Context, universityOnlineInfoList)
                recyclerDashboard.adapter = recyclerAdapter

                recyclerDashboard.layoutManager = layoutManager

                recyclerDashboard.addItemDecoration(
                    DividerItemDecoration(
                        recyclerDashboard.context,
                        (layoutManager as LinearLayoutManager).orientation
                    )
                )
                println("Appanki happened $universityOnlineInfoList")
                Toast.makeText(activity, "Internet Available", Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(activity, "No Connectivity", Toast.LENGTH_SHORT).show()
            }


        }, Response.ErrorListener {
            println("Appankisham Error is $it")
        }){

        }

        queue.add(jsonObjectRequest)

        return view
    }
    /*
    companion object {

        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            DashboardFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
     */
}