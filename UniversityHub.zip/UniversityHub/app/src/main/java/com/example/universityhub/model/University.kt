package com.example.universityhub.model

data class University(val name: String, val country: String, val webPages: String,
                      val alphaTwoCode: String, val domains: String
) {

}